package org.bouncycastle.cms;

public interface Recipient
{
}
