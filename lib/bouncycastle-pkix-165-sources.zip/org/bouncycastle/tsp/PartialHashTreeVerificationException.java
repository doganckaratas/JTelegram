package org.bouncycastle.tsp;

public class PartialHashTreeVerificationException extends Exception {

    public PartialHashTreeVerificationException(final String message)
    {
        super(message);
    }
}
