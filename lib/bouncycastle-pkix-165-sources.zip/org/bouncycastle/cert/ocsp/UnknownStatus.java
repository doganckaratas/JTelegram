package org.bouncycastle.cert.ocsp;

/**
 * wrapper for the UnknownInfo object
 */
public class UnknownStatus
    implements CertificateStatus
{
    public UnknownStatus()
    {
    }
}
